package com.example.ebookfrancis;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity extends AppCompatActivity {

    private Button profileButton;
    private Button bookListButton;
    private Button purchaseButton;
    private Button signupButton; // Sign Up button

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons
        profileButton = findViewById(R.id.profile_button);
        bookListButton = findViewById(R.id.book_list_button);
        purchaseButton = findViewById(R.id.purchase_button);
        signupButton = findViewById(R.id.signup_button); // Initialize Sign Up button

        // Set onClickListeners
        profileButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        bookListButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, BookListActivity.class);
            startActivity(intent);
        });

        purchaseButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PurchaseActivity.class);
            startActivity(intent);
        });

        // Set onClickListener for Sign Up button
        signupButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SignInActivity.class); // Navigate to SignUpActivity
            startActivity(intent);
        });
    }
}