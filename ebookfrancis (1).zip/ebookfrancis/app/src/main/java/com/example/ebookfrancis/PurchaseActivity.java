package com.example.ebookfrancis;

import android.os.Bundle;

import android.annotation.SuppressLint;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PurchaseActivity extends AppCompatActivity {

    private EditText bookTitleEditText;
    private EditText priceEditText;
    private Button purchaseButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase);

        bookTitleEditText = findViewById(R.id.editTextBookTitle);
        priceEditText = findViewById(R.id.editTextPrice);
        purchaseButton = findViewById(R.id.buttonPurchase);

        purchaseButton.setOnClickListener(v -> handlePurchase());
    }

    private void handlePurchase() {
        String bookTitle = bookTitleEditText.getText().toString();
        String price = priceEditText.getText().toString();

        if (bookTitle.isEmpty() || price.isEmpty()) {
            Toast.makeText(this, "Please enter both book title and price", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add further purchase handling logic here
    }
}